/* eslint-disable array-callback-return */
/* eslint-disable @typescript-eslint/no-unused-vars */
import logo from './logo.svg';
import './App.css';
import React, { Component } from "react";
import {
  Route,
  Link,
  BrowserRouter as Router,
  Switch
} from "react-router-dom";
import Details from "./components/details"
import BookList from "./components/booklist";
import {AddBook} from "./components/addbook";

function App(){
  return (
    <Router>
      <div>
        <h1>Book Management Store</h1>
        <ul className="header">
          <li><Link to="/">Home</Link></li>
          <li><Link to="/books">Book List</Link></li>
          <li><Link to="/add">Add Book</Link></li>
          <li><Link to="/login">Login</Link></li>
          <li><Link to="/register">Register</Link></li>
        </ul>
        <Switch>
          <Route exact path="/" component={BookList}/>
          <Route path="/books" component={BookList}/>
          <Route path="/add" component={AddBook}/>
          <Route path="/details/:id" component={Details}/>
        </Switch>
      </div>
    </Router>
  );
}
export default App;
